package com.example.retailstore.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CategoriesController {
	
	@GetMapping("/categories/categoryinsert")
	public String getCategoryInsert() {
		return "categories/categoryinsert";
		
	}
	@GetMapping("/categories/categoryupdate")
	public String getCategoryUpdate() {
		return "categories/categoryupdate";
		
	}
	@GetMapping("/categories/categorydelete")
	public String getCategoryDelete() {
		return "categories/categorydelete";
		
	}
	@GetMapping("/categories/categoryshow")
	public String getCategoryShow() {
		return "categories/categoryshow";
		
	}

}
