package com.example.retailstore.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SuppliersController {
	
	@GetMapping("/suppliers/supplierinsert")
	public String getSupplierInsert() {
		return "suppliers/supplierinsert";
		
	}
	@GetMapping("/suppliers/supplierupdate")
	public String getSupplierUpdate() {
		return "suppliers/supplierupdate";
		
	}
	@GetMapping("/suppliers/supplierdelete")
	public String getSupplierDelete() {
		return "suppliers/supplierdelete";
		
	}
	@GetMapping("/suppliers/suppliershow")
	public String getSupplierShow() {
		return "suppliers/suppliershow";
		
	}

}
