package com.example.retailstore.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class OrderDetailsController {
	
	@GetMapping("/orderdetails/orderdetailinsert")
	public String getOrderDetailInsert() {
		return "orderdetails/orderdetailinsert";
		
	}
	@GetMapping("/orderdetails/orderdetailupdate")
	public String getOrderDetailUpdate() {
		return "orderdetails/orderdetailupdate";
		
	}
	@GetMapping("/orderdetails/orderdetaildelete")
	public String getOrderDetailDelete() {
		return "orderdetails/orderdetaildelete";
		
	}
	@GetMapping("/orderdetails/orderdetailshow")
	public String getOrderDetailShow() {
		return "orderdetails/orderdetailshow";
		
	}

}
