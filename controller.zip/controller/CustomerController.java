package com.example.retailstore.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CustomerController {
	
	@GetMapping("/customer/customerinsert")
	public String getCustomerInsert() {
		return "customer/customerinsert";
		
	}
	@GetMapping("/customer/customerupdate")
	public String getCustomerUpdate() {
		return "customer/customerupdate";
		
	}
	@GetMapping("/customer/customerdelete")
	public String getCustomerDelete() {
		return "customer/customerdelete";
		
	}
	@GetMapping("/customer/customershow")
	public String getCustomerShow() {
		return "customer/customershow";
		
	}

}
