package com.example.retailstore.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "customers")
public class Customers {
	
	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	 private int Customer_ID;
	 
	 @Column(name = "First_Name")
	 private String First_Name; 
	 
	 @Column(name = "Last_Name")
	 private String Last_Name;
	 
	 @Column(name = "Address")
	 private String Address;
	 
	 @Column(name = "City")
	 private String City;
	 
	 @Column(name = "Zip_Code")
	 private int Zip_Code;
	 
	 @Column(name = "Country")
	 private String Country;
	 
	 @Column(name = "Phone_Number")
	 private int Phone_Number;
	 
	 @Column(name = "Birth_Date")
	 private Date Birth_Date;

}
