package com.example.retailstore.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "order_details")

public class Order_Details {
	
	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	 private int Order_Details_ID;
	 
	 @Column(name = "Order_ID")
	 private int Order_ID; 
	 
	 @Column(name = "Product_ID")
	 private int Product_ID;
	 
	 @Column(name = "Quantity")
	 private int Quantity; 
	 
	 @Column(name = "Unit_Price")
	 private double Unit_Price ;
	 
	 @Column(name = "Discount")
	 private double Discount;

}
