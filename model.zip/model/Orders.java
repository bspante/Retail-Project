package com.example.retailstore.model;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "orders")

public class Orders {
	
	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	 private int Order_ID;
	 
	 @Column(name = "Customer_ID")
	 private int Customer_ID; 
	 
	 @Column(name = "User_ID")
	 private int User_ID;
	 
	 @Column(name = "Purchase_Date")
	 private Date Purchase_Date;

}
