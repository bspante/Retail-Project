package com.example.retailstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetailStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
